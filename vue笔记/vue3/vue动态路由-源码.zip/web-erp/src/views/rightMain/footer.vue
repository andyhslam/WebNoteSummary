<template>
  <div class="main-footer fn-textcenter">
        <div>欢迎您!</div>
  </div>
</template>