<template>
  <div class="about">
    <h1>财务管理</h1>
  </div>
</template>
