<template>
  <div class="about">
    <h1>企业管理</h1>
  </div>
</template>
