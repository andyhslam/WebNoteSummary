<template>
    <div class="main-header fn-marginright">
        <ul class="breadcumb">
          <li>
            <span>首页</span>
          </li>
        </ul>
        <a class="exit"><i class="iconfont icontuichu">退出</i></a>
    </div>
</template>


